			</div> 
			<!-- /content -->
			<!-- footer -->
			<footer id="footer" class="footer" role="contentinfo">
				<div class="row contain">
					
				<!-- copyright -->
					<div>
						<p class="copyright">
							&copy; <?php echo date('Y'); ?> Copyright <?php bloginfo('name'); ?>. <?php _e('Powered by', 'html5blank'); ?>
							<a href="//wordpress.org" title="WordPress">WordPress</a>, <a href="//html5blank.com" title="HTML5 Blank">HTML5 Blank</a> & <a href="//natuive.net">natUIve WordPress</a>.
						</p>
						<a href=# class="backtotop">🔝</a>
					</div>
				<!-- /copyright -->
				</div>

			</footer>
			<!-- /footer -->

		<?php wp_footer(); ?>

	</body>
</html>
